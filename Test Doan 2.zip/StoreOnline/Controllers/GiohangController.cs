﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StoreOnline.Models;

namespace StoreOnline.Controllers
{
    public class GiohangController : Controller
    {
        // GET: Giohang
        dbStoreOnlineDataContext db = new dbStoreOnlineDataContext();
        public List<Giohang> Laygiohang()
        {
            List<Giohang> lstGiohang = Session["Giohang"] as List<Giohang>;
            if (lstGiohang==null)
            {
                //neu gio hang chua ton tai thi khoi taolistgiohang
                lstGiohang = new List<Giohang>();
                Session["Giohang"] = lstGiohang;
            }
            return lstGiohang;
        }
        //them gio hang
        public ActionResult Themgiohang(string smasp,string strURL)
        {
            //lay ra session gio hang
            List<Giohang> lstGiohang = Laygiohang();
            //kiem tra sp nay co ton tai trong session chua?
            Giohang sp = lstGiohang.Find(n => n.smasp == smasp);
            if (sp ==null)
            {
                sp = new Giohang(smasp);
                lstGiohang.Add(sp);
                return Redirect(strURL);
            }
            else
            {
                sp.isoluong++;
                return Redirect(strURL);
            }
        }
        private int Tongsoluong()
        {
            int itongsoluong = 0;
            List<Giohang> lstGiohang = Session["Giohang"] as List<Giohang>;
            if(lstGiohang!=null)
            {
                itongsoluong = lstGiohang.Sum(n => n.isoluong);
            }
            return itongsoluong;
        }
        //tinh tong tien
        private double Tongtien()
        {
            double itongtien = 0;
            List<Giohang> lstGiohang = Session["Giohang"] as List<Giohang>;
            if (lstGiohang!=null)
            {
                itongtien = lstGiohang.Sum(n => n.dthanhtien);
            }
            return itongtien;
        }
        public ActionResult Giohang()
        {
            List<Giohang> lstGiohang = Laygiohang();
            if (lstGiohang.Count==0)
            {
                return RedirectToAction("Index", "Shoponline");
            }
            ViewBag.Tongsoluong = Tongsoluong();
            ViewBag.Tongtien = Tongtien();
            return View(lstGiohang);
        }
        //Tao Partial view de hien thi thong tin gio hang
        public ActionResult GiohangPartial()
        {
            ViewBag.Tongsoluong = Tongsoluong();
            ViewBag.Tongtien = Tongtien();
            return PartialView();
        }
        //Cap nhat Giỏ hàng
        public ActionResult CapnhatGiohang(string smasp, FormCollection f)
        {

            //Lay gio hang tu Session
            List<Giohang> lstGiohang = Laygiohang();
            //Kiem tra sach da co trong Session["Giohang"]
            Giohang sanpham = lstGiohang.SingleOrDefault(n => n.smasp == smasp);
            //Neu ton tai thi cho sua Soluong
            if (sanpham != null)
            {
                sanpham.isoluong = int.Parse(f["txtSoluong"].ToString());
            }
            return RedirectToAction("Giohang");
        }
        //Xoa Giohang
        public ActionResult XoaGiohang(string smasp)
        {
            //Lay gio hang tu Session
            List<Giohang> lstGiohang = Laygiohang();
            //Kiem tra sach da co trong Session["Giohang"]
            Giohang sanpham = lstGiohang.SingleOrDefault(n => n.smasp == smasp);
            //Neu ton tai thi cho sua Soluong
            if (sanpham != null)
            {
                lstGiohang.RemoveAll(n => n.smasp == smasp);
                return RedirectToAction("GioHang");

            }
            if (lstGiohang.Count == 0)
            {
                return RedirectToAction("Index", "Shoponline");
            }
            return RedirectToAction("GioHang");
        }
        //Xoa tat ca thong tin trong Gio hang
        public ActionResult XoaTatcaGiohang()
        {
            //Lay gio hang tu Session
            List<Giohang> lstGiohang = Laygiohang();
            lstGiohang.Clear();
            return RedirectToAction("Index", "Shoponline");
        }
        public ActionResult Index()
        {
            return View();
        }
    }
}