﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StoreOnline.Models
{
    public class Giohang
    {
        dbStoreOnlineDataContext data = new dbStoreOnlineDataContext();
        public string smasp { get; set; }
        public string stensp { get; set; }
        public string sanhbia { get; set; }
        public Double ddongia { get; set; }
        public int isoluong { get; set; }
        public Double dthanhtien
        {
            get { return isoluong * ddongia; }
        }
        //khoi tao gio hang
        public Giohang(string masp)
        {
            smasp = masp;
            SANPHAM sp = data.SANPHAMs.Single(n => n.MASP == smasp);
            stensp = sp.TENSP;
            sanhbia = sp.HINHANH;
            ddongia = double.Parse(sp.GIABAN.ToString());
            isoluong = 1;

        }
    }
}